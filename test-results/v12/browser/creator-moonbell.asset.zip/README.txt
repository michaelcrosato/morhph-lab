MORPH LAB 11 / COMPLETE COVERAGE

Moon bell

Open model.glb in a glTF 2.0 application. Enable vertex colors in your material importer.
Import source.morph.json into Morph Lab to edit the recipe.
Read manifest.json and audit.json before game integration.

Geometry comes from the offline Inspector, not a capture of the WebGL2 Workshop.
Materials use linear vertex colors and standard metallic/roughness values. Fine pattern detail, bump textures, and custom shaders are not exported.
Motion is a sampled vertex bake. It has no reusable skeleton, retargeting, root-motion track, terrain contact, or physical collision data.
No loop is forced. Play once by default; inspect the reported endpoint gap before looping.
The source blueprint is the editable asset. Regenerate after changing proportions, parts, or actions.
Technical checks do not approve self-intersections, equipment fit, anatomy, or production quality.

No engine packages, fonts, or external files are needed to load this GLB.
No shader, physics, or target-game approval is included.
